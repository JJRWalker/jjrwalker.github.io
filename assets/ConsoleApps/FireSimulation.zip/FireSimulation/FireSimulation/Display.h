#ifndef DISPLAY_H
#define DISPLAY_H

#include <string>
#include <cstdlib>
#include <iostream>

using namespace std;

class Display
{
private:
	char map[21][21];
public:
	Display();
	void drawBorder();
	void update(int x, int y, char changeTo);
	void draw();
};

#endif