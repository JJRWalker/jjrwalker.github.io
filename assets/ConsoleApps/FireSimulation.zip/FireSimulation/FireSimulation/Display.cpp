#include "Display.h"


Display::Display()
{

}
//Adds the border to the trees
void Display::drawBorder()
{
	for (int y = 0; y < 21; y++)
	{
		for (int x = 0; x < 21; x++)
		{
			if (y == 0 || y == 20)
			{
				map[x][y] = '|';
			}
			else if (x == 0 || x == 20)
			{
				map[x][y] = '_';
			}
		}
	}
}


//updates the char values of the tree grid
void Display::update(int x, int y, char changeTo)
{

	if (changeTo != NULL)
	{
		map[x][y] = changeTo;
	}

	drawBorder();

}
//Draws the map to the console
void Display::draw()
{
	for (int y = 0; y < 21; y++)
	{
		for (int x = 0; x < 21; x++)
		{
			cout << ' ' << map[y][x] << ' ' ;
		}
		cout << endl;

	}

	cout << "Press enter to advance the time step, or press q to exit" << endl;
}
