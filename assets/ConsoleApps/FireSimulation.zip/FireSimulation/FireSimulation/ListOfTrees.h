#ifndef LISTOFTREES_H
#define LISTOFTREES_H

#include "Display.h"
#include <string>
#include <cstdlib>
#include <iostream>

using namespace std;

enum class status { notBurning,burning, empty };

class TreeNode
{
public:
	status* currentStatus;
private:
	int* posX;
	int* posY;
	bool burning;
	TreeNode* prev;
	TreeNode* next;
public:
	TreeNode();
	TreeNode(int x, int y, TreeNode* previous);
	TreeNode* getPrevious();
	TreeNode* getNext();
	void setPrev(TreeNode* prevNode);
	void setNext(TreeNode* nextNode);
	int* getPosX();
	int* getPosY();
	bool isBurning();
	void setBurning(bool state);
	void changeStatus(status changeTo);
	bool checkSpaces(TreeNode& a, TreeNode& b);
	~TreeNode();
};

class TreeList
{
private:
	TreeNode *start, *end;
	int damp;
public:
	TreeList(int dampLvl);
	bool isEmpty();
	void addTree(int x, int y, TreeNode* previous);
	void addFirstTree(int x, int y);
	void updateDisplay(Display display, int timeStep);
	void popTreeList(TreeList* list);
	void spreadFire();
	void removeEmpty();
	void listAllTrees();
};

#endif