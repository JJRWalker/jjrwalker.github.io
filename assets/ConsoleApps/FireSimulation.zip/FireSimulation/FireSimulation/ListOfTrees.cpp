#include "ListOfTrees.h"


#pragma region TREE NODES & FUNCTIONS
//Default constructor
TreeNode::TreeNode()
{
	posX = NULL;
	posY = NULL;
	next = NULL;
}
//Constructor that takes a x and y position aswell as the previous item in the list
TreeNode::TreeNode(int x, int y, TreeNode* previous)
{
	posX = new int(x);
	posY = new int(y);
	prev = previous;
	next = NULL;
}
//Gets the previous node of the currentally selected node
TreeNode * TreeNode::getPrevious()
{
	return prev;
}
//Sets the previous node used for patching the list together when an item is removed
void TreeNode::setPrev(TreeNode * prevNode)
{
	prev = prevNode;
}
//Sets the next node of the list, used in the same way as the previous
void TreeNode::setNext(TreeNode* nextNode)
{
	next = nextNode;
}
//Gets the next node in the list, used primaraly for itterating through the list
TreeNode* TreeNode::getNext()
{
	return next;
}
//Gets the x position of the object on the grid
int* TreeNode::getPosX()
{
	return posX;
}
//gets the y position of the object on the grid
int* TreeNode::getPosY()
{
	return posY;
}
//bool used to represent if a tree is burning, used on the first pass of the list (Check phase) for the node to be set to burning in the second pass. this is to stop trees
//that are not next to the burning one from being set to burning
bool TreeNode::isBurning()
{
	return burning;
}
//Used to set the state of the burning bool
void TreeNode::setBurning(bool state)
{
	burning = state;
}
//Used to change the satus of a node (e.g. burning, not burning and empty), Uses enum
void TreeNode::changeStatus(status changeTo)
{
	currentStatus = new status( changeTo );
}


//Checks the spaces that are within 1 unit of distance from the burning tree, returns true if there is a burning tree next to the node on the grid
bool TreeNode::checkSpaces(TreeNode & start, TreeNode& end)
{
	bool result = false;
	int x = *end.getPosX() - *start.getPosX();
	int y = *end.getPosY() - *start.getPosY();

	if ((x > -2 && x < 2) && (y > -2 && y <2))
	{
		result = true;
	}
	return result;
}
//called on destruction of a tree node
TreeNode::~TreeNode()
{
	// Checks if the next object in the list is not null, and then sets that items previous variable to be the current ones previous
	if (next != NULL)
	{
		next->setPrev(prev);
	}
	//Same as previous but changes the previous' next variable
	if (prev != NULL)
	{
		prev->setNext(next);
	}
	//Deleting varibles that are stored in the object / node
	delete posX;
	delete posY;
	delete currentStatus;
}

#pragma endregion

#pragma region TREE LIST & FUNCTIONS
//Constructor for the tree list.
TreeList::TreeList(int dampLvl)
{
	damp = dampLvl;
	start = NULL;
	end = NULL;
}
//Checks if the list is empty
bool TreeList::isEmpty()
{
	return start == NULL;
}
//Will add a tree to the end of the list
void TreeList::addTree(int x, int y, TreeNode* previous)
{
	TreeNode* current;
	//if the list currentaly has no end then it will use addFirstTree function, if not then it will just add a tree to the end
	if (end == NULL)
	{
		addFirstTree(x, y);
	}
	else
	{
		current = new TreeNode(x, y, previous);
		end->setNext(current);
		end = current;
	}
}

void TreeList::addFirstTree(int x, int y)
{
	// sets the start and end to be the current node that was created
	TreeNode* current;
	current = new TreeNode(x, y, NULL);
	start = current;
	end = current;
}

//Used to update the display with the trees current state
void TreeList::updateDisplay(Display display, int timeStep)
{
	TreeNode* current;
	char mapChar;
	//First checks to see if the list is empty
	if (!isEmpty())
	{
		//Then itterates through the list changing the output char dependent on the status of the tree.
		current = start;
		while (current != NULL)
		{
			switch (*current->currentStatus)
			{
			case status::notBurning:
				mapChar = '^';
				break;
			case status::burning:
				mapChar = 'f';
				break;
			case status::empty:
				mapChar = ' ';
				break;
			default:
				mapChar = '!';
				break;
			}
			//Updates the display to the current map character
			display.update(*(current->getPosX()) , *(current->getPosY()) , mapChar);
			current = current->getNext();
		}
		//Clears the screen before drawing redrawing
		system("cls");
		cout << "Current time step: " << timeStep << endl;
		cout << "_________________________________" << endl;
		display.draw();
	}
	else
		//error message which tells you if the list is empty
		cout << "List is Empty" << endl;
}


//Populates a list of trees
void TreeList::popTreeList(TreeList* list)
{
	TreeNode* current;
	TreeNode* previous;
	//itterates through x and y coordinates
	for (int y = 0; y < 20; y++)
	{
		for (int x = 0; x < 20; x++)
		{
			//sets the local previous node to the end of the list
			previous = list->end;
			//adds the tree to the list with the current coordinates, as well as assigning the previous node to the current tree
			list->addTree(x+1, y+1, previous);
			//sets the current node to be the end of the list
			current = list->end;
			//Sets the middle tree to burning
			if (*(current->getPosX()) == 10 && *(current->getPosY()) == 10)
			{
				current->changeStatus(status::burning);
			}
			//initalizes the status for the current tree
			else
			{
				current->changeStatus(status::notBurning);
			}
		}
	}
}
//Used between display updates to check the areas around a burning tree and changes them to burning accordingly
//Done in two passes, the first checking which trees are near a burning one and updating the is burning varible
//The second is setting the trees status to burning, where is burning is true.
void TreeList::spreadFire()
{
	TreeNode* current;
	TreeNode* check;
	int x;
	int y;
	int b;

	if (!isEmpty())
	{
		current = start;
		while (current != NULL)
		{
			if (*current->currentStatus == status::burning)
			{				
				check = start;
				while (check != NULL)
				{
					if (check->checkSpaces(*check, *current) && *check->currentStatus == status::notBurning)
					{
						b = rand() % 100;
						//Uses the dampness level input by the user to determine the chance of something catching fire.
						switch (damp)
						{
						case 1:
							if (b >= 50)
							{
								check->setBurning(true);
							}
							break;
						case 2:
							if (b >= 70)
							{
								check->setBurning(true);
							}
							break;
						case 3:
							if (b >= 80)
							{
								check->setBurning(true);
							}
							break;
						default:
							if (b >= 50)
							{
								check->setBurning(true);
							}
							break;
						}

					}
					
					check = check->getNext();
				}
			}
			current = current->getNext();
		}
		current = start;
		while (current != NULL)
		{
			if (*current->currentStatus == status::burning)
			{
				current->changeStatus(status::empty);
				current->setBurning(false);
			}
			if (current->isBurning())
			{
				current->changeStatus(status::burning);
			}

			current = current->getNext();
		}
	}
}
//Goes through the list and removes empty nodes, done to improve efficentcy in later stages of itteration.
//Removed from main as it causes NULL characters to appear.
void TreeList::removeEmpty()
{
	TreeNode* current;
	TreeNode* next;
	if (!isEmpty())
	{
		current = start;
		while (current != NULL)
		{
			next = current->getNext();

			if (*current->currentStatus == status::empty)
			{
				if (current->getNext() == NULL)
				{
					end = current->getPrevious();
				}
				if (current->getPrevious() == NULL)
				{
					start = current->getNext();
				}
				delete current;
			}
			current = next;
		}
	}
}
//Lists all the trees in the list, used for debuging
void TreeList::listAllTrees()
{
	TreeNode* current;

	if (!isEmpty())
	{
		cout << "List Start" << endl;
		current = start;
		char stat;
		while (current != NULL)
		{
			cout << "Next Tree is at position X:" << *(current->getPosX()) << " Y:" << *(current->getPosY());
			switch (*current->currentStatus)
			{
			case status::notBurning:
				stat = '^';
				break;
			case status::burning:
				stat = 'f';
				break;
			case status::empty:
				stat = ' ';
				break;
			default:
				stat = ' ';
			}
			cout << " Status:" << current->isBurning() << endl;
			current = current->getNext();
		}
		cout << "List End" << endl << endl;
	}
	else
		cout << "List is Empty" << endl;
}
#pragma endregion
