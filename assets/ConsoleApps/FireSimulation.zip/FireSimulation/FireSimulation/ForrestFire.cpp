#include "Display.h"
#include "ListOfTrees.h"
#include <ctime>



int main(void)
{
	//seeds the random number generation with the current time.
	srand(time(NULL));
	//Creates instances of classes
	Display forrest;

	//gets the user to input a mosture level for the simulation.
	bool dampLoop = true;
	char damp;
	int intDamp = 0;
	cout << "1) Dry" << endl;
	cout << "2) Moist" << endl;
	cout << "3) Damp" << endl;
	cout << "Please input a dampness level" << endl;
	//Loops the input until it recieves a vailid input
	while (dampLoop)
	{
		cin.get(damp);

		if (isdigit(damp))
		{
			intDamp = damp - '0';
		}
		else if (!isdigit(damp))
		{
			cout << "Please input a number between 1 and 3" << endl;
		}
		if (intDamp > 0 && intDamp < 4)
		{
			dampLoop = false;
		}
	}

	TreeList* trees = new TreeList(intDamp);

	int timeStep = 1;
	//Populates a list of trees for each location on the grid
	trees->popTreeList(trees);
	//Initalizes the tree grid and draws it on the console
	trees->updateDisplay(forrest, timeStep);
	
	bool end = false;
	char input;
	while (!end)
	{
		cin.get(input);
		if (input == 'q')
		{
			end = true;
		}

		trees->spreadFire();
		timeStep++;
		trees->updateDisplay(forrest, timeStep);
		//other functions, remove empty causes output issues
		//trees->removeEmpty();
		//Lists all of the trees in the list along with their x and y + their status
		//trees->listAllTrees();

	}

}