Vuforia Augmented Reality SDK Release Package
==============================================
Vuforia support Unity 5.3.6 or newer
To learn more about Vuforia, go to https://developer.vuforia.com/library/getting-started
To view the SDK license agreement, go to https://developer.vuforia.com/legal/vuforia-developer-agreement
To view the release notes, go to https://developer.vuforia.com/library/release-notes

/*============================================================================
            Copyright (c) 2010-2015 PTC Inc.
            All Rights Reserved.
            Confidential and Proprietary - PTC Inc.
  ============================================================================*/
