﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rail_Zombie : MonoBehaviour {

    int hp = 5;
    float speed = 2;
    bool canMove = true;
    bool canAttack = true;
    [SerializeField]
    GameObject player;
    Vector3 startPos, endPos, newPos;
    Rail_Player playerInstance;
    bool active;

	// Use this for initialization
	void Start () {
        active = false;
        playerInstance = Rail_Player.Instance;
        player = GameObject.Find("Player");
	}
	
	// Update is called once per frame
	void Update ()
    {
        //Disabled if paused, ar is lost or game is over
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.PLAY)
        {
            if (active)
            {
                if (canMove)
                {
                    StartCoroutine(Move());
                }
                else if (!canMove)
                {
                    StopCoroutine(Move());
                }

            }
        }
    }
    public void Reset()
    {
        hp = 5;
        active = false;
    }

    //Moves the Enemy towards the player waits and then moves again
    IEnumerator Move()
    {
        //faces the sprite / hitboxes directly towards the camera, giving it a billboard effect even when the player is rotated
        transform.LookAt(transform.position + Camera.main.transform.rotation * Vector3.forward, Camera.main.transform.rotation * Vector3.up);
        //Moves towards the player if they are not in range to attack using the current position and the players position
        startPos = transform.position;
        endPos = player.transform.position;

        newPos = startPos - endPos;
        //Gives the distance from the player
        float distance = Vector3.Distance(startPos, endPos);
        //Normalizes the vector to give direction without magnitude
        newPos = newPos.normalized;
        //If they are not close enough they will move towards the player
        if (distance > 5)
        {
            transform.position -= (newPos * speed) * Time.deltaTime;
        }
        //if they are close enough and they can attack they will do damage to the player
        if (distance <= 5 && canAttack == true)
        {
            StartCoroutine(Attack());
            canAttack = false;
        }
        if (distance > 5)
        {
            yield return new WaitForSeconds(1);
            canMove = false;
            yield return new WaitForSeconds(1);
            canMove = true;
        }

    }
    IEnumerator Attack()
    {
        yield return new WaitForSeconds(2);
        playerInstance.TakeDamage(1);
        canAttack = true;
    }
    //public accessor for the enemy's HP
    public int HP
    {
        get
        {
            return hp;
        }
        set
        {
            hp = value;
        }
    }
    public bool Active
    {
        get
        {
            return active;
        }
        set
        {
            active = value;
        }
    }

}
