﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rail_Spawner : MonoBehaviour {
    [SerializeField]
    GameObject left, tleft, right,tright, origin;

    enum GeoType {LEFT, RIGHT, TLEFT, TRIGHT}
    GeoType type;
    int x;
    List<GameObject> areas = new List<GameObject>();
    GameObject newObject;
    Vector3 direction;
    Vector3 previousPos;
    Quaternion currentAngle;
    Quaternion newRotation;
    Rail_ScreenTransition screen;
    // Use this for initialization
    void Start ()
    {
        areas.Add(origin);
        screen = transform.gameObject.GetComponent<Rail_ScreenTransition>();
        x = Random.Range(0, 3);
        direction = Vector3.left;
        currentAngle = Quaternion.Euler(0, 0, 0);
        newRotation = Quaternion.Euler(0, 0, 0);
        previousPos = new Vector3(0, 0, 0);
        type = (GeoType) x;
    }

    public void Create()
    {
        switch(type)
        {
            case GeoType.LEFT:
                newObject = Instantiate(left, GetNexPos(), new Quaternion(0,0,0,0));
                if (direction == Vector3.down)
                {
                    //Right turn down, left turn up
                    newRotation = Quaternion.Euler(new Vector3(0, -90, 0));
                    direction = Vector3.right;
                }
                else if (direction == Vector3.up)
                {
                    //Right turn up, left turn down
                    newRotation = Quaternion.Euler(new Vector3(0, 90, 0));
                    direction = Vector3.left;
                }
                else if (direction == Vector3.left)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, 0, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.down;
                }
                else if (direction == Vector3.right)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, 180, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.up;
                }
                break;


            case GeoType.RIGHT:
                newObject = Instantiate(right, GetNexPos(), new Quaternion(0, 0, 0, 0));
                if (direction == Vector3.down)
                {
                    //Right turn down, left turn up
                    newRotation = Quaternion.Euler(new Vector3(0, 90, 0));
                    direction = Vector3.left;
                }
                else if (direction == Vector3.up)
                {
                    //Right turn up, left turn down
                    newRotation = Quaternion.Euler(new Vector3(0, -90, 0));
                    direction = Vector3.right;
                }
                else if (direction == Vector3.left)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, 180, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.up;
                }
                else if (direction == Vector3.right)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, 0, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.down;
                }
                break;


            case GeoType.TLEFT:
                newObject = Instantiate(tleft, GetNexPos(), new Quaternion(0, 0, 0, 0));
                if (direction == Vector3.down)
                {
                    //Right turn down, left turn up
                    newRotation = Quaternion.Euler(new Vector3(0, -180, 0));
                    direction = Vector3.right;
                }
                else if (direction == Vector3.up)
                {
                    //Right turn up, left turn down
                    newRotation = Quaternion.Euler(new Vector3(0, 0, 0));
                    direction = Vector3.left;
                }
                else if (direction == Vector3.left)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, -90, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.down;
                }
                else if (direction == Vector3.right)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, 90, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.up;
                }
                break;


            case GeoType.TRIGHT:
                newObject = Instantiate(tright, GetNexPos(), new Quaternion(0, 0, 0, 0));
                if (direction == Vector3.down)
                {
                    //Right turn down, left turn up
                    newRotation = Quaternion.Euler(new Vector3(0, 180, 0));
                    direction = Vector3.left;
                }
                else if (direction == Vector3.up)
                {
                    //Right turn up, left turn down
                    newRotation = Quaternion.Euler(new Vector3(0, 0, 0));
                    direction = Vector3.right;
                }
                else if (direction == Vector3.left)
                {                    
                    newRotation = Quaternion.Euler(new Vector3(0, -90, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.up;
                }
                else if (direction == Vector3.right)
                {
                    newRotation = Quaternion.Euler(new Vector3(0, 90, 0));
                    newObject.tag = "Turn";
                    direction = Vector3.down;
                }               
                break;
        }
        newObject.transform.localRotation = currentAngle * newRotation;
        Transform child = newObject.transform.GetChild(1);

        screen.Locations.Add(child.GetChild(0).gameObject);
        screen.Locations.Add(child.GetChild(1).gameObject);
        screen.Locations.Add(child.GetChild(2).gameObject);
        screen.Locations.Add(child.GetChild(3).gameObject);

        areas.Add(newObject);

        if (areas.Count > 2)
        {
            Destroy(areas[0]);
            areas.RemoveAt(0);
        }


        type = (GeoType)Random.Range (0, 3);
    }

    Vector3 GetNexPos()
    {
        Vector3 newPos = new Vector3 (0, 0, 0);
        if (direction == Vector3.right)
        {
            newPos = previousPos + new Vector3(500, 0, 0);
        }
        else if (direction == Vector3.left)
        {
            newPos = previousPos + new Vector3(-500, 0, 0);
        }
        else if (direction == Vector3.up)
        {
            newPos = previousPos + new Vector3(0, 0, 500);
        }
        else if (direction == Vector3.down)
        {
            newPos = previousPos + new Vector3(0, 0, -500);
        }
        previousPos = newPos;
        return newPos;
    }

}
