﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rail_Player : MonoBehaviour {

    static Rail_Player player;

    static int hp;
    static int lives;

    protected Rail_Player()
    {
        lives = 3;
        hp = 3;
    }

    public void TakeDamage(int damage)
    {
        hp -= damage;
        if (lives == 0 && hp <= 0)
        {
            Rail_GameManager.GameStateChange(Rail_GameManager.GameStates.GAMEOVER);
        }
        if (hp <= 0)
        {
            lives--;
            hp = 3;
        }        
        Debug.Log("HP: " + hp + " Lives: " + lives);
    }

    public static Rail_Player Instance
    {
        get
        {
            if (player == null)
            {
                player = new Rail_Player();
            }
            return player;
        }
    }

    public static int HP
    {
        get
        {
            return hp;
        }
        set
        {
            hp = value;
        }
    }

    public static int Lives
    {
        get
        {
            return lives;
        }
    }
}
