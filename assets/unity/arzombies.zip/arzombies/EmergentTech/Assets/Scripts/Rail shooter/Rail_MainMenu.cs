﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Windows.Speech;
using UnityEngine.SceneManagement;

public class Rail_MainMenu : MonoBehaviour {

    //Mic name max and min frequency
    string micName;
    int minFreq;
    int maxFreq;
    KeywordRecognizer recognizer;
    Dictionary<string, System.Action> keywords = new Dictionary<string, System.Action>();

    // Use this for initialization
    void Start ()
    {
        //Gets the name of the default mic
        micName = Microphone.devices[0];
        AudioSource audio = GetComponent<AudioSource>();

        //Gets the max hz of the microphone
        Microphone.GetDeviceCaps(micName, out minFreq, out maxFreq);

        //Constantly records voice clips for analysis
        audio.clip = Microphone.Start(micName, true, 3, maxFreq);
        audio.Play();

        //Keywords used for voice recognition
        keywords.Add("start", () => { StartCalled(); });

        recognizer = new KeywordRecognizer(keywords.Keys.ToArray());
        recognizer.OnPhraseRecognized += OnPhraseRecognized;

        recognizer.Start();
    }

    void StartCalled()
    {
        SceneManager.LoadScene(1);
    }

    void OnPhraseRecognized(PhraseRecognizedEventArgs args)
    {
        System.Action keywordAction;
        if (keywords.TryGetValue(args.text, out keywordAction))
        {
            keywordAction.Invoke();
        }
    }

    void Update()
    {
        if (Input.anyKey)
        {
            StartCalled();
        }
    }
}
