﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Windows.Speech;
//Script for handling inputs before they are passed to other scripts
public class Rail_Input : MonoBehaviour {

    //Mic name max and min frequency
    string micName;
    int minFreq;
    int maxFreq;
    //Mouse pos and reload bool for reload input
    Vector3 mousePos;
    //Vars used in public accessors
    static bool fire = false;
    static bool reload = false;
    static bool pause = false;
    //Aim x and Y used for targeting
    [SerializeField]
    GameObject target;
    static float aimX;
    static float aimY;
    Vector3 aim = new Vector3(0, 0, 0);
    static float rateOfFire = 0.25f;
    KeywordRecognizer recognizer;
    Dictionary<string, System.Action> keywords = new Dictionary<string, System.Action>();
    //Control states
    public enum ControlState { MOUSE, AR};
    static ControlState controlState;
    static bool arInverted = false;

    
	// Use this for initialization
	void Start ()
    {
        controlState = ControlState.AR;

        //Gets the name of the default mic
        micName = Microphone.devices[0];
        AudioSource audio = GetComponent<AudioSource>();

        //Gets the max hz of the microphone
        Microphone.GetDeviceCaps(micName,out minFreq,out maxFreq);

        //Constantly records voice clips for analysis
        audio.clip = Microphone.Start(micName, true, 3, maxFreq);
        audio.Play();

        //Keywords used for voice recognition
        if (recognizer == null)
        {
            //Different words used for fire
            keywords.Add("fire", () => { FireCalled(); });
            keywords.Add("bang", () => { FireCalled(); });
            keywords.Add("pew", () => { FireCalled(); });
            keywords.Add("shoot", () => { FireCalled(); });

            //Reload
            keywords.Add("reload", () => { ReloadCalled(); });

            //Pause and gameover keywords
            keywords.Add("pause", () => { PauseCalled(); });
            keywords.Add("unpause", () => { UnpauseCalled(); });
            keywords.Add("Invert", () => { InvertCalled(); });
            keywords.Add("reset", () => { ResetCalled(); });
            keywords.Add("retry", () => { ResetCalled(); });
            keywords.Add("quit", () => { QuitCalled(); });

            recognizer = new KeywordRecognizer(keywords.Keys.ToArray());
            recognizer.OnPhraseRecognized += OnPhraseRecognized;
        }
        recognizer.Start();
    }
	
	// Update is called once per frame
	void Update ()
    {
        mousePos = Input.mousePosition;
        Vector3 screenCoord = Camera.allCameras[1].WorldToScreenPoint(target.transform.position);

        //Fire when fire button is pressed, or three times when fire is called
        if (Input.GetButtonDown("Fire1"))
        {
            fire = true;
        }
        else if (Input.GetButtonUp("Fire1"))
        {
            fire = false;
        }

        //Reload is true if the cursor is near the edge of the screen or if reload is called via voice commands
        if ((aim.x > 0.95 || aim.x < 0.05 || aim.y > 0.95 || aim.y < 0.05))
        {
            StartCoroutine(ReloadTime());
        }

        //changes control state based on if there is an AR tracker present
        if (controlState == ControlState.AR && !arInverted)
        {
            aimX = screenCoord.x;
            aimY = screenCoord.y;
            aim = new Vector3(aimX, aimY, 0);
            aim = Camera.main.ScreenToViewportPoint(aim);
        }
        else if (controlState == ControlState.AR && arInverted)
        {
            aimX = Screen.width - screenCoord.x;
            aimY = screenCoord.y;
            aim = new Vector3(aimX, aimY, 0);
            aim = Camera.main.ScreenToViewportPoint(aim);
        }
        else if (controlState == ControlState.MOUSE)
        {
            aimX = mousePos.x;
            aimY = mousePos.y;
            aim = new Vector3(aimX, aimY, 0);
            aim = Camera.main.ScreenToViewportPoint(aim);
        }

        //Inputs regarding Paused
        if (Input.GetKeyDown(KeyCode.Escape) && !pause)
        {
            pause = true;
        }
        else if (Input.GetKeyDown(KeyCode.Escape) && pause)
        {
            pause = false;
        }
        if (pause && Rail_GameManager.GameState != Rail_GameManager.GameStates.PAUSED)
        {
            Rail_GameManager.GameStateChange(Rail_GameManager.GameStates.PAUSED);
        }
        else if (!pause && Rail_GameManager.GameState == Rail_GameManager.GameStates.PAUSED)
        {
            Rail_GameManager.GameStateChange(Rail_GameManager.GameStates.PLAY);
        }

    }

    IEnumerator WaitToFire ()
    {
        fire = true;
        yield return new WaitForSeconds(rateOfFire * 3);
        fire = false;
    }

    IEnumerator ReloadTime()
    {
        reload = true;
        yield return new WaitForSeconds(1.5f);
        reload = false;
    }

    //Voice commands and button presses
    void OnPhraseRecognized(PhraseRecognizedEventArgs args)
    {
        System.Action keywordAction;
        if (keywords.TryGetValue(args.text,out keywordAction))
        {
            keywordAction.Invoke();
        }
    }

    void FireCalled()
    {
        StartCoroutine(WaitToFire());
        Debug.Log("Fire");
    }

    void ReloadCalled()
    {
        StartCoroutine(ReloadTime());
        Debug.Log("Reload");
    }

    void PauseCalled()
    {
        pause = true;
    }

    public void UnpauseCalled()
    {
        pause = false;
    }

    public void InvertCalled()
    {
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.PAUSED)
        {
            if (arInverted)
            {
                arInverted = false;
            }
            else if (!arInverted)
            {
                arInverted = true;
            }
        }
    }

    public void QuitCalled()
    {
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.PAUSED || Rail_GameManager.GameState == Rail_GameManager.GameStates.GAMEOVER)
        {
            Application.Quit();
        }
    }

    public void ResetCalled()
    {
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.GAMEOVER)
        {
            Rail_GameManager.GameStateChange(Rail_GameManager.GameStates.RESET);
        }
    }

    #region PUBLIC ACCESSORS
    public static bool Fire
    {
        get
        {
            return fire;
        }
    }

    public static bool Reload
    {
        get
        {
            return reload;
        }
    }

    public static float RateOfFire
    {
        get
        {
            return rateOfFire;
        }
    }

    public static float AimX
    {
        get
        {
            return aimX;
        }
    }

    public static float AimY
    {
        get
        {
            return aimY;
        }
    }

    public static ControlState Control
    {
        get
        {
            return controlState;
        }
        set
        {
            controlState = value;
        }
    }

    public static bool Invert
    {
        get
        {
            return arInverted;
        }
    }
    #endregion
}
