﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Rail_GameManager : MonoBehaviour {

    [SerializeField]
    List<GameObject> zombie;
    static int zombieIndex = 0;
    public enum GameStates { PAUSED, PLAY, GAMEOVER, TRACKERLOST, RESET}
    static GameStates gameState;
	// Use this for initialization
	  
    
    void Awake()
    {
        gameState = GameStates.PLAY;
    }
    	
    public static void GameStateChange(GameStates state)
    {
        gameState = state;
        switch (gameState)
        {
            case GameStates.PLAY:
                Rail_UI.UpdateARLost(false);
                Rail_UI.SetPauseActive(false);
                break;
            case GameStates.TRACKERLOST:
                Rail_UI.UpdateARLost(true);                
                Rail_Input.Control = Rail_Input.ControlState.MOUSE;
                break;
            case GameStates.PAUSED:
                Rail_UI.SetPauseActive(true);                
                break;
            case GameStates.GAMEOVER:
                Rail_UI.SetGameOverActive(true);
                break;
            case GameStates.RESET:
                SceneManager.LoadScene(1);
                break;
        }
    }

    public List<GameObject> Zombies
    {
        get
        {
            return zombie;
        }
    }

    public static int ZombieIndex
    {
        get
        {
            return zombieIndex;
        }
        set
        {
            zombieIndex = value;
        }
    }
    
    public static GameStates GameState
    {
        get
        {
            return gameState;
        }
    }

}
