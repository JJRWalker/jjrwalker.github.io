﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Used to activate a set of zombies that are attached to this game object.
//This is needed to stop zombies from always being active and walking through walls to get to the player
public class Rail_ZombieActivator : MonoBehaviour {

    GameObject gm;
    Rail_GameManager gameManager;
    Rail_Spawner spawner;
    Rail_ScreenTransition screen;
    GameObject player;
    
    List<GameObject> zombies = new List<GameObject>();

    void Start()
    {
        player = GameObject.Find("Player");
        gm = GameObject.Find("Game Manager");
        gameManager = gm.GetComponent<Rail_GameManager>();
        screen = gm.GetComponent<Rail_ScreenTransition>();
        spawner = gm.GetComponent<Rail_Spawner>();
        SpawnZombies();
    }

    void LateUpdate()
    {

        for(int i = 0; i < zombies.Count; i++)
        {
            if(zombies[i].GetComponent<Rail_Zombie>().HP <= 0)
            {
                zombies[i].transform.position -= new Vector3(0, 10, 0);
                zombies[i].GetComponent<Rail_Zombie>().Reset();
                zombies.RemoveAt(i);
            }
        }
        if (zombies.Count == 0)
        {
            screen.ChangeLocation(1);
        }
    }

    //Collision detection to check if the player is in the zone required to trigger the zombies
    public void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            //setting all zombies attached to active
            foreach (GameObject o in zombies)
            {
                o.GetComponent<Rail_Zombie>().Active = true;
            }
            spawner.Create();

        }
    }

    void SpawnZombies()
    {
        float offsetX = 0;
        float offsetZ = 0;
        zombies = new List<GameObject>();

        if (transform.parent.gameObject.tag == "Turn")
        {
            offsetZ = 5;
            offsetX = 0;
        }
        else
        {
            offsetX = 5;
            offsetZ = 0;
        }

        int x = Random.Range(3, 5);
        for (int i = 0; i < x; i++)
        {
            if (Rail_GameManager.ZombieIndex >= 19)
            {
                Rail_GameManager.ZombieIndex = 0;
            }

            gameManager.Zombies[Rail_GameManager.ZombieIndex].transform.position = this.gameObject.transform.position - new Vector3(0, 2, 0);
            gameManager.Zombies[Rail_GameManager.ZombieIndex].transform.LookAt(player.transform);
            gameManager.Zombies[Rail_GameManager.ZombieIndex].transform.localPosition -= new Vector3(offsetX, 0, offsetZ);
            zombies.Add(gameManager.Zombies[Rail_GameManager.ZombieIndex]);
            if (transform.parent.gameObject.tag == "Turn" )
            {
                offsetZ -= 5;
            }

            else
            {
                offsetX -= 5;
            }

            Rail_GameManager.ZombieIndex++;
        }
    }
}
