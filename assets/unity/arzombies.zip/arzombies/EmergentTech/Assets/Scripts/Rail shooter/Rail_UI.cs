﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Rail_UI : MonoBehaviour {

    //Serialized Variables used to set static variables that cannot be serialized
    [SerializeField]
    Image[] bulletsImages;
    [SerializeField]
    Image reticle;
    [SerializeField]
    Text scoreTxt, reloadTxt;
    [SerializeField]
    Image[] healthImages;
    [SerializeField]
    Text livesText, inverted;
    [SerializeField]
    Image muzzleFlash;
    [SerializeField]
    Sprite flash1, flash2;

    //Game objects that are parents of the menus, used to set menus as active or inactive
    [SerializeField]
    GameObject arLostUi, pauseMenu, gameOver;

    //Static Variables used in updating via static methods
    static GameObject arLostS, pauseS, gameOverS;
    static Sprite flash1s, flash2s;
    static Image muzzleFlashS, reticleS;
    static Text reloadTxtS;
    static int score;
    static int bullets;
    string invertText = "False";
    int previousBullets;
    int previousLives = 3;
    int previousHp = 3;

    // Use this for initialization
    void Start ()
    {
        //hides and contains the cursor within the window
        Cursor.lockState = CursorLockMode.Confined;
        Cursor.visible = false;
        previousBullets = bullets;
        //geting a reference to the text and images in static methods to the ones assigned in editor
        reloadTxtS = reloadTxt;
        flash1s = flash1;
        flash2s = flash2;
        muzzleFlashS = muzzleFlash;
        reticleS = reticle;
        arLostS = arLostUi;
        pauseS = pauseMenu;
        gameOverS = gameOver;
        //Setting UI elements to start as inactive
        UpdateARLost(false);
    }

    // Update is called once per frame
    void Update()
    {
        //Updates the reticle position to be the same as the mouse position
        reticleS.rectTransform.position = new Vector2(Rail_Input.AimX, Rail_Input.AimY);
        muzzleFlashS.rectTransform.position = new Vector2(Rail_Input.AimX, Rail_Input.AimY);
        //Updates score
        scoreTxt.text = ("Score: " + score);
        //If the number of current bullets has changed it will trigger a switch statement in the UpdateBullets method
        if (bullets != previousBullets)
        {
            UpdateBullets();
            previousBullets = bullets;
        }
        if (previousHp != Rail_Player.HP)
        {
            UpdateHealth();
            previousHp = Rail_Player.HP;
        }
        if (previousLives != Rail_Player.Lives)
        {
            UpdateLives();
            previousLives = Rail_Player.Lives;
        }


        //Updates Text showing the state of the invert varible inside input in the pause menu
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.PAUSED)
        {
            if (Rail_Input.Invert)
            {
                invertText = "True";
            }
            else if (!Rail_Input.Invert)
            {
                invertText = "False";
            }
            inverted.text = "Inverted: " + invertText;
        }

    }
    //Updates the UI display of bullets
    void UpdateBullets()
    {
        switch (bullets)
        {
            case 0:
                bulletsImages[5].gameObject.SetActive(false);
                break;
            case 1:
                bulletsImages[4].gameObject.SetActive(false);
                break;
            case 2:
                bulletsImages[3].gameObject.SetActive(false);
                break;
            case 3:
                bulletsImages[2].gameObject.SetActive(false);
                break;
            case 4:
                bulletsImages[1].gameObject.SetActive(false);
                break;
            case 5:
                bulletsImages[0].gameObject.SetActive(false);
                break;
            case 6:
                bulletsImages[0].gameObject.SetActive(true);
                bulletsImages[1].gameObject.SetActive(true);
                bulletsImages[2].gameObject.SetActive(true);
                bulletsImages[3].gameObject.SetActive(true);
                bulletsImages[4].gameObject.SetActive(true);
                bulletsImages[5].gameObject.SetActive(true);
                break;
        }
    }

    void UpdateHealth()
    {
        switch (Rail_Player.HP)
        {
            case 0:
                healthImages[2].gameObject.SetActive(false);
                healthImages[1].gameObject.SetActive(false);
                healthImages[0].gameObject.SetActive(false);
                break;
            case 1:
                healthImages[2].gameObject.SetActive(true);
                healthImages[1].gameObject.SetActive(false);
                healthImages[0].gameObject.SetActive(false);
                break;
            case 2:
                healthImages[2].gameObject.SetActive(true);
                healthImages[1].gameObject.SetActive(true);
                healthImages[0].gameObject.SetActive(false);
                break;
            case 3:
                healthImages[2].gameObject.SetActive(true);
                healthImages[1].gameObject.SetActive(true);
                healthImages[0].gameObject.SetActive(true);
                break;
        }
    }

    void UpdateLives()
    {
        switch (Rail_Player.Lives)
        {
            case 0:
                livesText.text = "X 0";
                break;
            case 1:
                livesText.text = "X 1";
                break;
            case 2:
                livesText.text = "X 2";
                break;
            case 3:
                livesText.text = "X 3";
                break;
        }
    }
    //Allows for the reload text to be show when you are reloading
    public static void UpdateReload(bool state)
    {
        reloadTxtS.gameObject.SetActive(state);
    }
    //Used to create a muzzle flash effect after the player shoots
    public static IEnumerator MuzzleFlash()
    {
        muzzleFlashS.gameObject.SetActive(true);
        muzzleFlashS.sprite = flash1s;
        yield return new WaitForSeconds(0.05f);
        muzzleFlashS.sprite = flash2s;
        yield return new WaitForSeconds(0.05f);
        muzzleFlashS.sprite = flash1s;
        muzzleFlashS.gameObject.SetActive(false);
    }
    
    public static void UpdateARLost(bool state)
    {
        //checks if the gameobject is not null, as on restart
        if (arLostS != null)
        {
            arLostS.SetActive(state);
            if (state)
            {
                reticleS.gameObject.SetActive(false);
                Cursor.visible = true;
            }
            else if (!state)
            {
                reticleS.gameObject.SetActive(true);
                Cursor.visible = false;
            }
        }
    }
    
    public static void SetPauseActive(bool state)
    {
        pauseS.SetActive(state);
        if (state)
        {
            reticleS.gameObject.SetActive(false);
            Cursor.visible = true;
        }
        else if (!state)
        {
            reticleS.gameObject.SetActive(true);
            Cursor.visible = false;
        }
    }

    public static void SetGameOverActive(bool state)
    {
        gameOverS.SetActive(state);
        Cursor.visible = true;
    }

    public void OnContPressed()
    {
        Rail_GameManager.GameStateChange(Rail_GameManager.GameStates.PLAY);
        Rail_Input.Control = Rail_Input.ControlState.MOUSE;
    }
    //Public accessors
    public static int Score
    {
        get
        {
            return score;
        }
        set
        {
            score = value;
        }
    }
    public static int Bullets
    {
        get
        {
            return bullets;
        }
        set
        {
            bullets = value;
        }
    }
}
