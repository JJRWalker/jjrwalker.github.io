﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rail_Fire : MonoBehaviour {


    int ammo;
    bool canFire = true;
    bool hasAmmo = true;
    bool reload = false;

	// Use this for initialization
	void Start ()
    {
        ammo = 6;
        Rail_UI.Bullets = ammo;
	}
	
	// Update is called once per frame
	void Update ()
    {
        //Disabled if paused, ar is lost or game is over
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.PLAY)
        {

            //if the player has not fired in a small amout of time and has ammo, the player will be able to fire
            if (Rail_Input.Fire && canFire && hasAmmo && !Rail_Input.Reload)
            {
                StartCoroutine(Fire());
                ammo--;
                Rail_UI.Bullets--;
            }
            // if the player moves the mouse tp the edge of the screen or activates the reload function in another way the gun will be reloaded

            if (Rail_Input.Reload && reload == false)
            {
                StartCoroutine(Reload(1.5f));
            }

            if (ammo == 0)
            {
                hasAmmo = false;
            }
        }
	}
    //Used to raycast from the player to the location targeted by the mouse
    IEnumerator Fire()
    {
        StartCoroutine(Rail_UI.MuzzleFlash());
        Ray dir = Camera.main.ScreenPointToRay(new Vector3(Rail_Input.AimX, Rail_Input.AimY));
        RaycastHit hit;
        if (Physics.Raycast(dir.origin, dir.direction, out hit))
        { 
            //checks the object hit, will do more damage if it is the head
            if (hit.collider.tag == "Target")
            {
                Rail_Zombie zombie = hit.collider.gameObject.GetComponentInParent<Rail_Zombie>();
                zombie.HP--;
                Rail_UI.Score++;
            }
            if (hit.collider.tag == "Head")
            {
                Rail_Zombie zombie = hit.collider.gameObject.GetComponentInParent<Rail_Zombie>();
                zombie.HP -= 2;
                Rail_UI.Score+= 5;
            }
        }
        //Makes the player wait until they can fire again (Rate of Fire)
        canFire = false;
        yield return new WaitForSeconds(Rail_Input.RateOfFire);
        canFire = true;
    }

    //Reloads when the cusor is at the sides of the screen
    IEnumerator Reload(float reloadTime)
    {
        reload = true;
        Rail_UI.UpdateReload(true);
        yield return new WaitForSeconds(reloadTime);
        Rail_UI.UpdateReload(false);
        ammo = 6;
        Rail_UI.Bullets = ammo;
        hasAmmo = true;
        reload = false;
    }
}
