﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rail_ScreenTransition : MonoBehaviour {
    //Moving the player
    [SerializeField]
    List<GameObject> locations;
    int currentLocation = 0;
    float distanceCov;
    float amountRot;
    float perRotated;
    float perComplete;
    [SerializeField]
    float speed = 1;
    [SerializeField]
    float rotationSpeed = 5;
    float startTime;
    float distance;
    float rotation;
    bool lerp = false;
    //Player object
    [SerializeField]
    GameObject player;
    //Used for auto lerping, for if the character goes round a courner with out reaching another gameplay area
    int timesLerped = 0;
    int timesToLerp = 0;

    void Awake()
    {
        List<GameObject> locations = new List<GameObject>();
    }

	// Update is called once per frame
	void Update ()
    {
        //Disabled if paused, ar is lost or game is over
        if (Rail_GameManager.GameState == Rail_GameManager.GameStates.PLAY)
        {
            //Auto Moves to the next location if the current is a mid or transition point
            if (locations[currentLocation].tag == "TransitionPoint")
            {
                ChangeLocation(1);
            }

            if (lerp == true)
            {
                //Moves and rotates the player to the next point using a list of locations and variables set when the change location method is called
                player.transform.position = Vector3.Lerp(locations[currentLocation].transform.position, locations[currentLocation + 1].transform.position, perComplete);
                player.transform.localRotation = Quaternion.Lerp(player.transform.rotation, locations[currentLocation + 1].transform.rotation, perRotated);
                distanceCov = (Time.time - startTime) * speed;
                amountRot = (Time.time - startTime) * rotationSpeed;
                perComplete = distanceCov / distance;
                //Checks that there is a change in angle, as to stop a divide by zero error
                if (rotation != 0)
                {
                    perRotated = amountRot / rotation;
                }

                //headbobbing
                Camera.main.transform.position += new Vector3(0, Mathf.Sin(Time.time * 5) / 80, 0);
                if (perComplete >= 1f)
                {
                    lerp = false;
                    currentLocation++;
                    //reseting camera y value
                    Camera.main.transform.position = new Vector3(player.transform.position.x, 3, player.transform.position.z);
                }

            }
        }
    }
    //Called when the player clears a screen, used to move to the next screen/point. 
    //Includes a setable amount of repeats that can be called if one of the points is used to turn a courner or is not a gameplay area
    public void ChangeLocation(int numOfLerps)
    {
        // making sure not to start a lerp whilst lerping
        if (lerp == false)
        {
            perComplete = 0;
            perRotated = 0;
            distanceCov = 0;
            amountRot = 0;
            timesToLerp = numOfLerps;
            // Checking to ensure there is a next location 
            if (locations[currentLocation + 1] != null)
            {
                //gets the distance to travel and the amount of rotation needed
                distance = Vector3.Distance(player.transform.position, locations[currentLocation + 1].transform.position);
                rotation = locations[currentLocation].transform.localRotation.y - locations[currentLocation + 1].transform.localRotation.y;
                startTime = Time.time;

                lerp = true;

            }
        }
    }

    public List<GameObject> Locations
    {
        get
        {
            return locations;
        }
        set
        {
            locations = value;
        }
    }
}
