﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Killbound : MonoBehaviour {

    GameObject player;
    GameObject obsticle;
    [SerializeField]
    Material mat;
    [SerializeField]
    AudioSource spikeHit;

    static GameManager gm;
    SpeedManager sm;
	// Use this for initialization
	void Awake ()
    {
        gm = GameManager.Instance;
        sm = SpeedManager.Instance;
        obsticle = this.gameObject;
	}
    //Checks the attached objects tag and then decides what to do, means that we do not need multiple scripts for obsticles
    void CheckTag ()
    {
        switch (obsticle.tag)
        {
            case "Fall":
                Fall();
                break;
            case "Spike":
                Spike();
                break;
            case "DeathWall":
                DeathWall();
                break;
            default:
                Fall();
                break;
        }
    }

    void Fall()
    {
        gm.SetGameState(GameManager.GameState.DEAD);
    }
    //Triggers when the player hits a spike
    void Spike()
    {
        Color c1 = Color.white;
        Color c2 = Color.red;

        spikeHit.Play(); 
        StartCoroutine(ChangeColour(c2, c1));
        
        sm.ChangeState(SpeedManager.MovementState.SLOWDOWN);
    }
    //Triggers when the player hits the wall of death
    void DeathWall()
    {
        gm.SetGameState(GameManager.GameState.GAMEOVER);
    }
    //Changes the colour of the player to indicate damage
    IEnumerator ChangeColour(Color colorChange, Color current)
    {
        mat.color = colorChange;
        yield return new WaitForSeconds(0.15f);
        mat.color = current;
    }
    //Checks the tag of the object, when the player hits one with this script attached
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            CheckTag();
        }
    }
}
