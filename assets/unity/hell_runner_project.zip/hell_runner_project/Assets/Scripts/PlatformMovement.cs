﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformMovement : MonoBehaviour {

    public static float groundSpeed = 30;
    private GameObject ground;
    GameManager gm;

    float timer;
	// Use this for initialization
	void Start ()
    {
        gm = GameManager.Instance;
        ground = this.gameObject;
        StartCoroutine(SpeedUp());
	}
	//Increases the ground speed every 5 secconds, and stops the speed from going over 70
    public IEnumerator SpeedUp()
    {
        bool loop = true;
        while (loop)
        {
            timer += Time.deltaTime;
            MoveGround(ground);
            if (timer > 5)
            {
                groundSpeed += 0.1f;
                timer = 0;
            }
            groundSpeed = Mathf.Clamp(groundSpeed, 0, 70);
            yield return null;
        }
    }
    //Moves the platforms towards the player
    void MoveGround (GameObject obj)
    {
        obj.transform.Translate(Vector3.left * groundSpeed * Time.deltaTime);
    }
    //Slows the player down, called when the player hits a spike (KillBound)
    public void SlowDown()
    {
        groundSpeed -= 7;
    }

}
