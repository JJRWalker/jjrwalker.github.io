﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectGeneration : MonoBehaviour {

    [SerializeField]
    GameObject[] objects;
    [SerializeField]
    GameObject player;
    [SerializeField]
    Transform parent;

    float objectSpawnTimer = 2.0f;
    bool posGot = false;
    float zPos = 0;
    int index = 0;
    Vector3 placement;

    static ObjectGeneration _instance;
    // Use this for initialization
    void Start ()
    {
        _instance = new ObjectGeneration();
        StartCoroutine(SpawnObject());
	}
    


    public IEnumerator SpawnObject()
    {
        bool loop = true;
        while (loop)
        {
            objectSpawnTimer -= Time.deltaTime;

            if (objectSpawnTimer <= 0)
            {
                int numOfObjectsSpawned = Random.RandomRange(1, 15);

                for (int i = 0; i <= numOfObjectsSpawned; i++)
                {
                    GetPlacement();
                    if (!CheckForGround(placement))
                    {
                        GetPlacement();
                    }
                    if (CheckForGround(placement))
                    {
                        if (index >= 15)
                        {
                            index = 0;
                        }
                        objects[index].transform.position = placement;
                        index++;
                        posGot = true;
                    }
                }
                posGot = false;
                objectSpawnTimer = Random.Range(0.4f, 2f);
            }
            yield return null;
        }
    }

    void GetPlacement()
    {
        if (!posGot)
        {
            zPos = Random.RandomRange(-15, 15);
            
        }
        if (posGot)
        {
            zPos += 2.5f;
        }
        placement = new Vector3(player.transform.position.x + 160, 2f, zPos);
    }
    bool CheckForGround(Vector3 position)
    {
        bool grounded = false;
        Vector3 minPos = new Vector3(position.x, position.y, position.z - 2.5f);
        Vector3 maxPos = new Vector3(position.x, position.y, position.z + 2.5f);
        if (Physics.Raycast(minPos, Vector3.down, 5f) && Physics.Raycast(maxPos, Vector3.down, 5f))
        {
            grounded = true;
        }
        return grounded;
    }
    
    public void CoroutineStart()
    {
        StartCoroutine(SpawnObject());
    }
    
    public void CoroutineStop()
    {
        StopCoroutine(SpawnObject());
    }

    public static ObjectGeneration Instance
    {
        get
        {
            return _instance;
        }
    }
}
