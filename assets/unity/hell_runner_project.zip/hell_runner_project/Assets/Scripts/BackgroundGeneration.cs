﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundGeneration : MonoBehaviour
{

    [SerializeField]
    GameObject[] objects;
    [SerializeField]
    GameObject player;
    [SerializeField]
    Transform parent;

    int index = 0;
    private float objectSpawnTime = 0.7f;


    void Awake()
    {
        StartCoroutine(SpawnPlatforms());
    }
    //Itterates through an array of premade objects and places then in the player
    public IEnumerator SpawnPlatforms()
    {
        bool loop = true;
        while (loop)
        {
            //moves objects based on the random spawn time
            objectSpawnTime -= Time.deltaTime;
            
            if (objectSpawnTime < 0.01f)
            {
                if (index >= 10)
                {
                    index = 0;
                }
                objects[index].transform.position = new Vector3(player.transform.position.x + 300, -40, Random.Range(-170, 170));
                index++;
                objectSpawnTime = Random.Range(PlatformMovement.groundSpeed / 50 + 1, PlatformMovement.groundSpeed / 50 + 1.25f);
            }
            yield return null;
        }
    }
}
