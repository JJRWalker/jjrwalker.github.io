﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class CameraMovement : MonoBehaviour {

    [SerializeField]
    Image image;
    [SerializeField]
    GameObject deathParticles, skullParticles;
    float fadeAmount = 0;
    [SerializeField]
    Material mat1;
    [SerializeField]
    Material mat2;

    //Instant of this class
    private static CameraMovement _instance;
    private CameraMovement()
    { }

	// Use this for initialization
	void Awake ()
    {
        _instance = new CameraMovement();
        mat1.color = new Color(mat1.color.r, mat1.color.g, mat1.color.b, 1);
        mat2.color = new Color(mat2.color.r, mat2.color.g, mat2.color.b, 1);
        image.CrossFadeAlpha(0f, 0f, false);
    }
    void Start()
    {
        StartCoroutine(DisableParticles());
    }
    // Update is called once per frame

    public void IncreaseVin(float increase)
    {
        fadeAmount += increase;
        image.CrossFadeAlpha(fadeAmount, 1f, false);
    }
    //Disables the wall of death particles as well as making the skull translucent
    IEnumerator DisableParticles ()
    {
        //Waits until the camera is not looking at the skull
        yield return new WaitForSeconds(5f);
        mat1.color = new Color(mat1.color.r, mat1.color.g, mat1.color.b, 0.25f);
        mat2.color = new Color(mat2.color.r, mat2.color.g, mat2.color.b, 0.25f);
        deathParticles.SetActive(false);
        skullParticles.SetActive(false);
    }
    public static CameraMovement Instance
    {
        get
        {
            return _instance;
        }
    }
}
