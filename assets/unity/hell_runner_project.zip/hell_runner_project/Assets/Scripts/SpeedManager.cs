﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class SpeedManager : MonoBehaviour {
    //enum, used for changing movement state
    public enum MovementState { SPEEDUP, SLOWDOWN, STOPPED};
    public MovementState moveState;
    //instance of this class
    private static SpeedManager _instance;
    //references to other classes
    static PlatformMovement platform;
    static WallOfDeath wall;
    static CameraMovement cm;
    //Delegate used for/on state change
    public delegate void StateChange();
    public event StateChange onStateChange;


    void Awake()
    {
        cm = GameObject.FindObjectOfType<CameraMovement>();
        platform = GameObject.FindObjectOfType<PlatformMovement>();
        wall = GameObject.FindObjectOfType<WallOfDeath>();
    }

    private SpeedManager()
    { }
    #region MOVE STATE CHANGE

    public void ChangeState(MovementState state)
    {
        this.moveState = state;
        switch (state)
        {
            case MovementState.SLOWDOWN:
                onStateChange += SlowDown;
                break;
            case MovementState.SPEEDUP:
                onStateChange += SpeedUp;
                break;
            case MovementState.STOPPED:

                break;
        }
        onStateChange();
    }
    void SlowDown()
    {
        //Various methods for when the player hits a spike.

        cm.IncreaseVin(0.2f);
        platform.SlowDown();
        wall.MoveCloser();
        onStateChange -= SlowDown;
    }
    void SpeedUp()
    {

        StartCoroutine(platform.SpeedUp());
        onStateChange -= SpeedUp;
    }
    #endregion

    public static SpeedManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new SpeedManager();
            }
            return _instance;
        }
    }
}
