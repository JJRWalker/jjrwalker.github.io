﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{

    [SerializeField]
    Text scoreUI;
    [SerializeField]
    Text highScoreUI;
    [SerializeField]
    Image[] livesUI;
    public GameObject platforms;
    private float start;
    private float current;
    private float difference;
    public float score;
    static GameManager gm;

    

    //get starting position for distance based score
    private void Start()
    {
        gm = GameManager.Instance;
        score = 0.0f;
        start = platforms.transform.position.x;
    }

    // Check for changes in score via:
    // -distance
    private void Update()
    {
      

        if (DataManagement.dataManagement.currentScore > DataManagement.dataManagement.highScore)
        {
            DataManagement.dataManagement.highScore = DataManagement.dataManagement.currentScore;
        }

        current = Mathf.Abs(platforms.transform.position.x);
        scoreUI.GetComponent<Text>().text = ("Score " + DataManagement.dataManagement.currentScore.ToString());
        highScoreUI.GetComponent<Text>().text = ("High Score " + DataManagement.dataManagement.highScore.ToString());

    }
    // -other scripts
    public void addScore(float scoreChange)
    {
        score = score + scoreChange;
    }
    //Updates the current display of lives by disabling an image in an array of heart images
    public void updateLives(int num)
    {
        livesUI[num].enabled = false;
    }
    //calculate distance difference and update score with.
    private void LateUpdate()
    {
        difference = (current - start);
        score = Mathf.Round(score + difference) / 10;
        //scoreUI.text = "Score: " + score;
        DataManagement.dataManagement.currentScore = score;
    }
}
