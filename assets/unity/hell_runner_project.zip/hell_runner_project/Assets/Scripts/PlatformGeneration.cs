﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformGeneration : MonoBehaviour {
    [SerializeField]
    GameObject[] platforms;
    [SerializeField]
    GameObject player;
    PlatformMovement platform;

    int index = 0;
    private float platformSpawnTime = 0.7f;
    float speed;

    void Awake()
    {
        StartCoroutine(SpawnPlatforms());
    }
    public IEnumerator SpawnPlatforms()
    {
        bool loop = true;
        while (loop)
        {
            speed = PlatformMovement.groundSpeed;
            platformSpawnTime -= Time.deltaTime;

            if (platformSpawnTime < 0.01f)
            {
                if (index >= 10)
                {
                    index = 0;
                }
                platforms[index].transform.position = new Vector3(player.transform.position.x + 160, 0, Random.Range(-2, 2));
                index++;
                if (speed < 45)
                {
                    platformSpawnTime = Random.Range(speed / 1000 + 1.55f, speed / 1000 + 1.7f);
                }
                else if ( speed > 45 && speed < 50)
                {
                    platformSpawnTime = Random.Range(speed / 1000f + 1.25f, speed / 1000f + 1.3f);
                }
                else if (speed > 50)
                {
                    platformSpawnTime = Random.Range(speed / 1000f + 1, speed / 1000f + 1.2f);
                }
            }
            yield return null;
        }
    }

}
