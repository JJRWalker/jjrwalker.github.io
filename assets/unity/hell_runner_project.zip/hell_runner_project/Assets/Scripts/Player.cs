﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {
    [SerializeField]
    static GameObject player;
    
    private static Player _instance;
    static GameManager gm;
    PlayerMovement playerMovement;

    Vector3 startPos;
    float moveDir;
    int lives = 3;
    bool doubleJump;
    bool speedBoost;
    bool isMoving;
    static bool isPaused = false;


    [SerializeField]
    AudioSource fx;

    private Player(int _lives, bool _doubleJump, bool _speedBoost)
    {

    }

	// Use this for initialization
	void Awake ()
    {
        playerMovement = FindObjectOfType<PlayerMovement>();
        player = GameObject.Find("Player");
        gm = GameManager.Instance;
        Debug.Log("Player instance created");
        _instance = new Player(3, false, false);
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Checks for inputs made by the player and calls the relevent methods.

        if (Input.GetButtonDown("MoveLeft"))
        {
            //Checks to make sure that the player is not currently moving, so the player does not get stuck between lanes
            if (!isMoving)
            {
                isMoving = true;
                playerMovement.LerpLeft();

            }
            //Sets moving bool to false after the player has finished moving
            isMoving = false;
        }

        if (Input.GetButtonDown("MoveRight"))
        {
            if (!isMoving)
            {
                isMoving = true;
                playerMovement.LerpRight();

            }
            isMoving = false;
        }

        if (Input.GetButtonDown("Jump"))
        {
            if (!isMoving)
            {
                //Plays the jump sound effect
                fx.Play();
                isMoving = true;
                playerMovement.Jump(player);

            }
            isMoving = false;
        }
        //Toggles pause depending on a isPaused bool
        if (!isPaused)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                isPaused = true;
                gm.SetGameState(GameManager.GameState.PAUSED);
            }
        }
        else if (isPaused)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                isPaused = false;
                gm.SetGameState(GameManager.GameState.UNPAUSE);
            }
        }

    }
    //Resets the players position to the origin, removes a life and triggers a game over if the player has 0 lives
    public void Respawn()
    {
        lives -= 1;
        if (lives<=0)
        {
            gm.SetGameState(GameManager.GameState.GAMEOVER);
        }
        
        player.transform.position = new Vector3(0, 3f, 0);
    }
    #region PUBLIC ACCESSORS

    //Acessors used for changing variables.
    public bool DoubleJump
    {
        get
        {
            return doubleJump;
        }
    }
    public bool SpeedBoost
    {
        get
        {
            return speedBoost;
        }
    }
    public int Lives
    {
        get
        {
            return lives;
        }
    }
    public static bool IsPaused
    {
        get
        {
            return isPaused;
        }
        set
        {
            isPaused = value;
        }
    }
    //used for getting an instance of Player outside of this class (Game Manager)
    public static Player Instance
    {
        get
        {
            return _instance;
        }
    }
    #endregion
}
