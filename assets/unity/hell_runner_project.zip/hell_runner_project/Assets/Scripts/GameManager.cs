﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class GameManager : MonoBehaviour {
    //Enum Used for gamestate change
    public enum GameState { UNPAUSE, DEAD, GAMEOVER, PAUSED};
    public GameState gameSate;
    //instances of classes
    private static GameManager _instance;
    Player player;
    Score score;


    //Delegate used for/on state change
    public delegate void StateChange();
    public event StateChange onStateChange;

    //UI elements
    static GameObject pauseUI;
    static GameObject gameOverUI;
    static GameObject howToPlayUI;

    private  GameManager ()
    {
    }

	// Use this for initialization

    void Start ()
    {
        DataManagement.dataManagement.LoadData();
    }

	void Awake ()
    {
        // Getting UI elements
        pauseUI = GameObject.Find("Pause");
        gameOverUI = GameObject.Find("Game Over");
        howToPlayUI = GameObject.Find("HowToPlay");
        Cursor.visible = false;
        //Getting instance of the player class
        player = Player.Instance;
        //Setting the UI elements to inactive
        pauseUI.SetActive(false);
        gameOverUI.SetActive(false);
        howToPlayUI.SetActive(false);
    }
	
    #region GAMESTATE CHANGE
    //Used for changing the game state in other classes
    public void SetGameState(GameState state)
    {
        gameSate = state;
        {
            switch(gameSate)
            {
                case GameState.UNPAUSE:
                    onStateChange += UnPause;
                    break;
                case GameState.DEAD:
                    onStateChange += PlayerDeath;

                    break;
                case GameState.GAMEOVER:
                    onStateChange += GameOver;
                    PlayerDies();
                    break;
                case GameState.PAUSED:
                    onStateChange += Paused;
                    break;
            }
        }
        onStateChange();
    }
    //Used to respawn the player when they die, also updates the UI
    void PlayerDeath()
    {
        player = Player.Instance;
        score = FindObjectOfType<Score>();
        score.updateLives(player.Lives - 1);
        player.Respawn();
        onStateChange -= PlayerDeath;
    }
    // called when player lives = 0
    void GameOver()
    {
        //Destroys the pause menu to stop unpausing when in a game over
        Destroy(pauseUI);
        Cursor.visible = true;
        //pauses the game.
        Time.timeScale = 0;
        //Activates the game over menu.
        gameOverUI.SetActive(true);
        onStateChange -= GameOver;
    }
    //Called from player class to unpause game when the escape button is pressed.
    public void Paused()
    {
        //Checks to make sure that a pause menu exists. Important as the menu is deleted when there is a game over to stop the player from unpausing in a game over state
        if (pauseUI != null)
        {
            Player.IsPaused = true;
            Time.timeScale = 0;
            Cursor.visible = true;
            pauseUI.SetActive(true);
            gameSate = GameState.PAUSED;
        }
        onStateChange -= Paused;
    }
    //Called from player class to unpause game when the escape button is pressed / called when resume button is pressed on pause menu
    public void UnPause()
    {
        //Checks to make sure that a pause menu exists. Important as the menu is deleted when there is a game over to stop the player from unpausing in a game over state
        if (pauseUI != null)
        {
            Player.IsPaused = false;
            Time.timeScale = 1;
            Cursor.visible = false;
            pauseUI.SetActive(false);
            howToPlayUI.SetActive(false);
            gameSate = GameState.UNPAUSE;
        }

        onStateChange -= UnPause;
    }
    //Called when the retry button is pressed after a game over
    public void Retry()
    {
        //Unloads scene and reloads it, then unpauses the game and resets the ground speed
        SceneManager.UnloadSceneAsync(SceneManager.GetActiveScene().buildIndex);
        SceneManager.LoadScene((int)SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1;
        PlatformMovement.groundSpeed = 30;
    }
    //called from pause menu and game over menu
    public void Quit()
    {
        Application.Quit();
    }

    public void ShowHowToPlay()
    {
        howToPlayUI.SetActive(true);
    }
    public void HideHowToPlay()
    {
        howToPlayUI.SetActive(false);
    }
    #endregion

    #region PUBLIC ACCESSORS
    //Used for getting an instance of the gamemanager class outside of this class (Player)
    public static GameManager Instance
    {
       get
        {
            if (_instance == null)
            {
                _instance = new GameManager();
            }
            return _instance;
        }
    }

    public void PlayerDies ()
    {
        DataManagement.dataManagement.SaveData();
    }

    #endregion
}
