﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallOfDeath : MonoBehaviour {

    float timeTakenToLerp = 0.3f;
    const int lerpDistance = 1;

    private bool isLerping;

    private Vector3 startPos;
    private Vector3 endPos;

    private float timeLerpingStarted;

	// Use this for initialization
	
    void Update()
    {
        LerpObject();
    }

    void LerpObject()
    {
        if (isLerping)
        {
            //Increases the percentage of movement over time
            float timeSinceStart = Time.time - timeLerpingStarted;
            float perComplete = timeSinceStart / timeTakenToLerp;

            this.transform.position = Vector3.Lerp(startPos, endPos, perComplete);

            //Resets the is lerping varible if the lerp is complete
            if (perComplete >= 1.0f)
            {
                isLerping = false;
            }
        }
    }

    public void MoveCloser()
    {
        isLerping = true;
        timeLerpingStarted = Time.time;
        startPos = this.transform.position;
        endPos = this.transform.position + new Vector3(4, 0, 0);
    }

}
