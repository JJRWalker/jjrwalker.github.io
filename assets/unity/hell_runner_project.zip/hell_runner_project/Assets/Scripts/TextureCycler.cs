﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//A script writen to cycle through textures, used to create tessalating animated textures.
public class TextureCycler : MonoBehaviour {

    //array of images to be cycled through
    [SerializeField]
    Texture[] images;
    //material effected by cycling images
    [SerializeField]
    Material mat;
    int length;
    int i;
	// Use this for initialization
	void Start ()
    {
        //gets length and sets index to 0
        length = images.Length;
        i = 0;
        StartCoroutine(CycleTextures());
	}

    IEnumerator CycleTextures()
    {
        bool loop = true;
        // loops through and changes the main texture of the material to the texture in the array at the position of the index
        while (loop)
        {
            mat.SetTexture("_MainTex", images[i]);
            yield return new WaitForSeconds(0.015f);
            //adds 1 to the index
            i++;
            //if the index is the same as the length of the texture array, the index is set to 0. To avoid an out of range exeption
            if (i == length)
            {
                i = 0;
            }
            yield return null;
        }
    }
}
