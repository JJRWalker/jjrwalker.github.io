﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    float jumpSpeed = 3f;

    private float timeTakenTolerpHorizontal = 0.12f;
    private float timeTakenTolerpJumping = 0.4f;
    const int lerpDistance = 1;

    private bool isLerping;
    private bool isJumping;

    private Vector3 startPos;
    private Vector3 endPos;
    private float gravity = 9.8f;

    private float timeLerpingStarted;

    // Use this for initialization
    void Start()
    {
        StartCoroutine(Lerping());
        StartCoroutine(Grav());
    }

    #region MOVING LEFT / RIGHT

    public IEnumerator Lerping()
    {
        bool loop = true;
        while (loop)
        {
            if (isLerping)
            {
                //Increases the percentage of movement over time
                float timeSinceStart = Time.time - timeLerpingStarted;
                float perComplete = timeSinceStart / timeTakenTolerpHorizontal;

                this.transform.position = Vector3.Lerp(startPos, endPos, perComplete);

                //Resets the is lerping varible if the lerp is complete
                if (perComplete >= 1.0f)
                {
                    isLerping = false;
                }
            }
            if (isJumping)
            {

                //Increases the percentage of movement over time
                float timeSinceStart = Time.time - timeLerpingStarted;
                float perComplete = timeSinceStart / timeTakenTolerpJumping;
                this.transform.position = Vector3.Lerp(startPos, endPos, perComplete);

                //Resets the is lerping varible if the lerp is complete
                if (perComplete >= 1.0f)
                {
                    isJumping = false;
                }
            }

            yield return null;
        }
    }
    // moves the player downwards if they are not touching the ground
    public IEnumerator Grav()
    {
        bool loop = true;
        while (loop)
        {
            if (!IsGrounded(this.gameObject))
            {
                transform.Translate(new Vector3(0, -gravity * Time.deltaTime, 0));
            }
            yield return null;
        }
    }
    //Called when the input in player is left
    public void LerpLeft()
    {
        if (!isJumping)
        {
            isLerping = true;
            timeLerpingStarted = Time.time;
            //Sets the start and end positions for lerping
            startPos = this.transform.position;
            endPos = this.transform.position + Vector3.forward * lerpDistance * 2;
        }

    }
    //Called when the input in player is right
    public void LerpRight()
    {
        if (!isJumping)
        {
            isLerping = true;
            timeLerpingStarted = Time.time;
            //Sets the start and end positions for lerping
            startPos = this.transform.position;
            endPos = this.transform.position + Vector3.back * lerpDistance * 2;
        }

    }

    #endregion

    #region JUMPING
    public void Jump(GameObject obj)
    {
        if (IsGrounded(obj))
        {

            isJumping = true;
            timeLerpingStarted = Time.time;

            startPos = this.transform.position;
            endPos = this.transform.position + Vector3.up * (lerpDistance + 1 * jumpSpeed);
        }
    }

    //Moves the player towards the camera if they are hit by a moving platform
    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Ground")
        {
            this.transform.position += new Vector3(-0.5f, 0, 0);
        }
    }

    //Used to check if the player (or any object) is touching the ground
    public bool IsGrounded(GameObject obj)
    {
        {
            bool grounded = false;
            Vector3 offset = new Vector3(0.75f, 0, 0);
            Vector3 ray = new Vector3(obj.transform.position.x, obj.transform.position.y - (obj.transform.localScale.y / 2f -0.02f), obj.transform.position.z);

            if (Physics.Raycast(ray - offset, Vector3.down, 0.7f)|| Physics.Raycast(ray + offset, Vector3.down, 0.7f))
            {
                grounded = true;
            }
            //Insert double jump check code here?
            return grounded;
        }
        #endregion
    }
}
