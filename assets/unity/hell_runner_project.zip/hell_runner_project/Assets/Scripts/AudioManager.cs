﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {

    [SerializeField]
    AudioClip start, loop, end;
    [SerializeField]
    AudioSource audio;
    bool startPlayed;

    static GameManager gm;
	// Use this for initialization
	void Start () {
        audio.clip = start;
        gm = GameManager.Instance;
        StartCoroutine(PlayMusic());
    }
//Used for looping the music
    IEnumerator PlayMusic()
    {
        bool looping = true;
        while (looping)
        {
            //Checks to see if the intro was played, returns false on the first itteration
            if (startPlayed)
            {
                //Changes the clip to the loopable audio track
                audio.clip = loop;
            }
            if (gm.gameSate == GameManager.GameState.GAMEOVER)
            {
                audio.clip = end;
            }
            //Plays the currently selected track
            audio.Play();
            //waits for the current track to finish
            yield return new WaitForSeconds(audio.clip.length);
            //Sets start played to true, so on the second itteration the loop is played
            startPlayed = true;
            yield return null;
        }


    }
}
